#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
/**
  * @ClassName ${NAME}
  * @Desciption TODO
  * @Author ${USER}
  * @Date ${DATE} ${TIME}
  * @Version 1.0
  **/
public enum ${NAME} {
}