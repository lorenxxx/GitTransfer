#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @Author ${USER}
 * @Description TODO
 * @Date ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
 * @Version 1.0
 **/
public class ${NAME} {
}
